<?php

# -------website topfreefaucet.com--------

$ua = "user-agent: Mozilla/5.0 (Linux; U; Android 9; in-id; CPH1969 Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/70.0.3538.80 Mobile Safari/537.36 HeyTapBrowser/25.7.1.1";

# ---------------DOGE----------------------

$doge = "https://trivisna.com/content/auto/claim.php?coin=DOGE"; 

$cdoge = "cookie: LTCToken=OBBEM7xW9zNRGpIm1tmKMsnFehhKEMrv; ETHToken=g6EzGtwlgdFSJgT1FmCKNWYIgf9MgO2N; BCNToken=fY9hdefpwNMIKPOZ5oGr4wkbwt7QjbUl; DGBToken=YNiUsCjZEUH1ooQQQk5vAObYbqAkibNB; POTToken=itwzIWMevWwhFhBX6QLYEyrBkSqqgsfj; DOGEToken=4QsX3eQvWzo6j0Kpw6nP8bfvMLT6LKzB; PHPSESSID=335d07d63bd653193ccc3106b5efaf60; PHPSESSID=335d07d63bd653193ccc3106b5efaf60; PHPSESSID=335d07d63bd653193ccc3106b5efaf60; _ga=GA1.2.707345537.1588257324; _gid=GA1.2.439204048.1588257324; adcashufpv3=82935730618982128787497545; 494668b4c0ef4d25bda4e75c27de2817=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1; dom3ic8zudi28v8lr6fgphwffqoz0j6c=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1; _data_html=430-20; _data_cpm=336-2_425-4";

# ---------------TRX----------------------
$trx = "https://trivisna.com/content/auto/claim.php?coin=TRX";

$ctrx = "cookie: DOGEToken=RH3KHZBnNpDvNi6AfstrQKX3mIqUP6g7; TRXToken=WizuqJX6dF4MaM6zid1hIFVCESXtbZmK; PHPSESSID=c5115084fdd5325fc705e3f0517877cf; 494668b4c0ef4d25bda4e75c27de2817=078928cc-fb26-4028-990f-e226e1ad5bb0%3A1%3A2; dom3ic8zudi28v8lr6fgphwffqoz0j6c=078928cc-fb26-4028-990f-e226e1ad5bb0%3A1%3A2; _data_html=429-7_430-2; _ga=GA1.2.653834706.1588245720; _gid=GA1.2.794559949.1588245720; adcashufpv3=1119725300279356672703493198; _data_cpm=336-2_425-4";

#---------------LTC----------------------

$ltc = "https://trivisna.com/content/auto/claim.php?coin=LTC";

$cltc = "cookie: DOGEToken=h1ZxJ2znZ3gY6QzsNFQn6KlQWMGZ6tAB; LTCToken=OBBEM7xW9zNRGpIm1tmKMsnFehhKEMrv; PHPSESSID=335d07d63bd653193ccc3106b5efaf60; _ga=GA1.2.707345537.1588257324; _gid=GA1.2.439204048.1588257324; adcashufpv3=82935730618982128787497545; _data_html=430-1; _data_cpm=336-1_425-1; 494668b4c0ef4d25bda4e75c27de2817=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1";

#---------------ETH----------------------

$eth = "https://trivisna.com/content/auto/claim.php?coin=ETH";

$ceth = "cookie: DOGEToken=h1ZxJ2znZ3gY6QzsNFQn6KlQWMGZ6tAB; LTCToken=OBBEM7xW9zNRGpIm1tmKMsnFehhKEMrv; ETHToken=g6EzGtwlgdFSJgT1FmCKNWYIgf9MgO2N; PHPSESSID=335d07d63bd653193ccc3106b5efaf60; _ga=GA1.2.707345537.1588257324; _gid=GA1.2.439204048.1588257324; adcashufpv3=82935730618982128787497545; _data_cpm=336-1_425-1; 494668b4c0ef4d25bda4e75c27de2817=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1; dom3ic8zudi28v8lr6fgphwffqoz0j6c=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1; _data_html=430-3";

#---------------BCN----------------------

$bcn = "https://trivisna.com/content/auto/claim.php?coin=BCN";


$cbcn = "cookie: DOGEToken=h1ZxJ2znZ3gY6QzsNFQn6KlQWMGZ6tAB; LTCToken=OBBEM7xW9zNRGpIm1tmKMsnFehhKEMrv; ETHToken=g6EzGtwlgdFSJgT1FmCKNWYIgf9MgO2N; BCNToken=fY9hdefpwNMIKPOZ5oGr4wkbwt7QjbUl; PHPSESSID=335d07d63bd653193ccc3106b5efaf60; _ga=GA1.2.707345537.1588257324; _gid=GA1.2.439204048.1588257324; adcashufpv3=82935730618982128787497545; _data_cpm=336-1_425-1; 494668b4c0ef4d25bda4e75c27de2817=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1; dom3ic8zudi28v8lr6fgphwffqoz0j6c=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1; _data_html=430-8";

#---------------DGB----------------------

$dgb = "https://trivisna.com/content/auto/claim.php?coin=DGB";

$cdgb = "cookie: LTCToken=OBBEM7xW9zNRGpIm1tmKMsnFehhKEMrv; ETHToken=g6EzGtwlgdFSJgT1FmCKNWYIgf9MgO2N; BCNToken=fY9hdefpwNMIKPOZ5oGr4wkbwt7QjbUl; DOGEToken=D0cNJr61Ib6scoS0AUoV6CHQrofgmv2r; DGBToken=YNiUsCjZEUH1ooQQQk5vAObYbqAkibNB; PHPSESSID=335d07d63bd653193ccc3106b5efaf60; _ga=GA1.2.707345537.1588257324; _gid=GA1.2.439204048.1588257324; adcashufpv3=82935730618982128787497545; 494668b4c0ef4d25bda4e75c27de2817=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1; dom3ic8zudi28v8lr6fgphwffqoz0j6c=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1; _data_cpm=336-1_425-4; _data_html=430-18; _gat_gtag_UA_153694246_1=1";

#---------------POT----------------------

$pot = "https://trivisna.com/content/auto/claim.php?coin=POT";

$cpot = "cookie: LTCToken=OBBEM7xW9zNRGpIm1tmKMsnFehhKEMrv; ETHToken=g6EzGtwlgdFSJgT1FmCKNWYIgf9MgO2N; BCNToken=fY9hdefpwNMIKPOZ5oGr4wkbwt7QjbUl; DOGEToken=D0cNJr61Ib6scoS0AUoV6CHQrofgmv2r; DGBToken=YNiUsCjZEUH1ooQQQk5vAObYbqAkibNB; POTToken=itwzIWMevWwhFhBX6QLYEyrBkSqqgsfj; POTToken=itwzIWMevWwhFhBX6QLYEyrBkSqqgsfj; PHPSESSID=335d07d63bd653193ccc3106b5efaf60; _ga=GA1.2.707345537.1588257324; _gid=GA1.2.439204048.1588257324; adcashufpv3=82935730618982128787497545; 494668b4c0ef4d25bda4e75c27de2817=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1; dom3ic8zudi28v8lr6fgphwffqoz0j6c=d8b3e4a2-51aa-4f91-8c2c-9ad19be6d36b%3A3%3A1; _data_cpm=336-1_425-4; _data_html=430-20; _gat_gtag_UA_153694246_1=1";
/*

// isi file config seperti diatas
// work all link autoclaim via express crypto

$doge = "xxxxxx";
$codoge = "cookie: xxxxxxxx";

$trx = "xxxxxx";
$ctrx = "cookie: xxxxxxxx";

$ltc = "xxxxxx";
$cltc = "cookie: xxxxxxxx";

$eth = "xxxxxx";
$ceth = "cookie: xxxxxxxx";

$bcn = "xxxxxx";
$cbcn = "cookie: xxxxxxxx";

$pot = "xxxxxx";
$cpot = "cookie: xxxxxxxx";

*/
?>